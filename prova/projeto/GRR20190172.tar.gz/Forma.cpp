#include "Forma.hpp"

Forma::Forma(std::string tipo) : tipo{tipo} {}