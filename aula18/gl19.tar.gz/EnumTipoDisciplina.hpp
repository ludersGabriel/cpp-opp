#ifndef ENUM_TIPO_DISCIPLINA_HPP
#define ENUM_TIPO_DISCIPLINA_HPP

namespace ufpr{
enum class EnumTipoDisciplina{
    OPTATIVA,
    MANDATORIA};
}
#endif